# caliclaw

Your own personal AI assistant. Any server. Any task. The claw way. 🔱

**The first and only personal AI assistant built for Claude.** No API key — just your subscription.

## Why caliclaw

Other AI assistants (openclaw, etc.) require API keys, manual configuration, and don't support Claude at all. caliclaw is different:

- **Zero config** — `caliclaw start` does everything. Setup, dependencies, pairing — automatic
- **No API key** — runs on your Claude subscription. No tokens, no billing surprises
- **No TOS violations** — built on official tools, not reverse engineering
- **Agents that actually work** — spawn agents on the fly, run them in parallel (swarm), chain them (pipeline), or let them work autonomously (loop) until the task is done
- **They remember** — persistent memory across sessions. Your assistant learns who you are and how you work
- **They have a soul** — personality, rules, and behavior defined in simple markdown files, not buried in code
- **They know when to stop** — anti-hallucination layer, permission levels, human approval for dangerous actions. Type `stop` and everything halts instantly
- **Secure by default** — prompt injection protection, input filtering, and encrypted vault built in. No setup needed
- **They work while you sleep** — cron jobs, scheduled heartbeats, automated checks
- **Smart with your limits** — tracks usage as % of daily limit, auto-downgrades models when you're running hot

## caliclaw vs openclaw

| | caliclaw | openclaw |
|---|---|---|
| Claude support | **Yes** | No |
| API key required | **No** — subscription only | Yes |
| Setup time | **One command** | Manual config |
| Agents spawn agents | **Yes** | No |
| Agents work autonomously | **Yes** — loops with limits | No |
| Agents extract knowledge on death | **Yes** | No |
| Prompt injection protection | **Built in** | Manual |
| Memory across sessions | **Yes** | Varies |
| Soul system | **Yes** | Yes |
| Scheduled tasks | **Built in** | Plugin |
| Voice messages | **Built in** | No |
| Open source | **Yes** | Yes |

## What you get

- **Telegram bot** — text, voice, photos, files. Streaming responses. Inline controls
- **20+ commands** — agents, tasks, memory, skills, model switching, all from Telegram
- **Terminal chat** — TUI alternative when you're already in the terminal
- **Voice** — send voice messages, whisper-cpp transcribes them
- **Skills system** — enable/disable capabilities. Create your own in markdown
- **Encrypted vault** — store secrets your agents can use
- **Health dashboard** — web UI for monitoring usage and status
- **Migration** — coming from openclaw/nanoclaw/zeroclaw? One command imports everything

## Quick start

```bash
git clone https://github.com/califlaw/caliclaw.git
cd caliclaw
source install.sh
caliclaw start
```

First run triggers setup automatically. Pair with your bot by sending `/pair <code>` in Telegram.

That's it. No YAML configs. No Docker. No environment variables to hunt down.

## Requirements

- Python 3.10+
- Claude Code CLI
- Telegram bot token ([@BotFather](https://t.me/BotFather))

## How agents work

> When you kill an agent, it doesn't just die — it extracts everything it learned into memory. The next agent picks up where it left off. Knowledge never dies.

```
You send a message in Telegram
  -> caliclaw loads the agent's soul, memory, and skills
  -> Agent processes your request with full system access
  -> Response streams back to Telegram in real-time
  -> Conversation saved, memory updated

Need parallel work?
  -> /spawn researcher "find all bugs in auth module"
  -> /spawn fixer "fix the bugs researcher found"
  -> They work independently, report back to you

Need autonomous work?
  -> /loop "refactor the entire test suite"
  -> Agent works in iterations until done or you say stop

Need scheduled work?
  -> /cron "0 9 * * *" "check server health and report"
  -> Runs every morning, sends you the result
```

## Migration

Coming from another *claw project?

```bash
caliclaw migrate ~/path/to/old-project
```

Auto-detects project type. Migrates soul, memory, skills, database. Supports openclaw, nanoclaw, zeroclaw.

## Deploy

```bash
# Local
pip install -r requirements.txt && caliclaw start

# VPS
scp -r caliclaw/ user@vps:~/caliclaw/
ssh user@vps "cd caliclaw && pip install -r requirements.txt && caliclaw start"

# Systemd (auto-restart on failure)
sudo cp caliclaw.service /etc/systemd/system/
sudo systemctl enable --now caliclaw
```

Auto-reconnects on network drops. Graceful shutdown. PID management built in.

## License

Personal use.
