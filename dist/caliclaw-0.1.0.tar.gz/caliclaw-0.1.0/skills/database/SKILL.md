---
name: database
description: Database management, queries, migrations
---

## Before any changes
- Back up the database
- Test on a copy first
- Use transactions for multi-step changes

## Queries
- Use EXPLAIN to check query plans
- Add indexes for frequently queried columns
- Avoid SELECT * in production code

## Migrations
- Always reversible (up + down)
- Test migration on a copy of production data
- Never drop columns/tables without confirming data is backed up
