---
name: coding
description: Write, review, and debug code
---

## When writing code
- Read existing code before modifying
- Follow the project's existing style and conventions
- Write tests alongside new code
- Keep changes minimal — don't refactor what wasn't asked

## When debugging
- Read the error message carefully
- Check the relevant file and surrounding context
- Form a hypothesis before making changes
- Verify the fix works

## When reviewing
- Check for bugs, not style preferences
- Look for security issues (injection, XSS, hardcoded secrets)
- Verify error handling at system boundaries
