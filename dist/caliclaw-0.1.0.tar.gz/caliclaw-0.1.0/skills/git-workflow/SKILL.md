---
name: git-workflow
description: Git operations, branching, PRs, code review
---

## Commits
- Write clear commit messages (what and why)
- One logical change per commit
- Never commit secrets, .env, or credentials

## Branches
- Feature branches from main
- Keep branches short-lived
- Rebase or merge based on project convention

## Pull Requests
- Clear title and description
- List what changed and why
- Include test plan
