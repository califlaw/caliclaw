---
name: docker
description: Docker containers, images, compose
---

## Operations
- docker ps — check running containers
- docker logs <container> — check logs
- docker stats — resource usage
- docker compose up/down — manage stacks

## Best practices
- Use specific image tags, not :latest
- Multi-stage builds for smaller images
- Don't run as root inside containers
- Use .dockerignore
- Health checks in Dockerfile/compose
