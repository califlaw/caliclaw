---
name: server-admin
description: Server management, monitoring, troubleshooting
---

## Monitoring
- Check: df -h, free -m, uptime, top -bn1
- Check logs: journalctl -n 50, /var/log/syslog, /var/log/nginx/error.log
- Check services: systemctl status <service>
- Check ports: ss -tlnp

## Troubleshooting
1. Identify the symptom (what's failing)
2. Check logs for errors
3. Check resource usage (disk, RAM, CPU)
4. Check recent changes (git log, apt log)
5. Fix root cause, not symptoms

## Security
- Keep packages updated
- Check for open ports that shouldn't be
- Verify firewall rules
- Check for failed SSH login attempts
