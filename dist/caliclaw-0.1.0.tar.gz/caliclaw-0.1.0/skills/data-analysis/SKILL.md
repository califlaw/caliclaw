---
name: data-analysis
description: Analyze data, generate reports, find patterns
---

## Process
1. Understand what question we're answering
2. Examine the data (format, size, quality)
3. Clean and prepare data if needed
4. Analyze (aggregate, filter, compare)
5. Present findings clearly

## Output
- Lead with the key finding
- Include numbers and comparisons
- Visualize when helpful (tables, charts)
- Note limitations and caveats
