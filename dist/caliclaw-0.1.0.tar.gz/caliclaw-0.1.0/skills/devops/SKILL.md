---
name: devops
description: CI/CD, deployment, infrastructure management
---

## Deployment
1. Always check current state before deploying (git status, docker ps)
2. Run tests before deploy
3. Back up current state / note rollback steps
4. Deploy
5. Verify health after deploy
6. Report result

## Rollback
- Keep track of previous version/commit
- If health check fails — rollback immediately, then investigate

## Infrastructure
- Use infrastructure as code when possible
- Document manual changes in memory
- Never hardcode secrets — use vault or environment variables
