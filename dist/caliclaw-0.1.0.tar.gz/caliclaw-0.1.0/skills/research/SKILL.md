---
name: research
description: Research topics, gather information, write summaries
---

## Process
1. Understand the question clearly
2. Search for relevant information
3. Cross-reference multiple sources
4. Summarize findings concisely
5. Cite sources when possible

## Output format
- Start with a one-line answer
- Then supporting details
- List sources/references at the end
- Flag uncertainty explicitly
