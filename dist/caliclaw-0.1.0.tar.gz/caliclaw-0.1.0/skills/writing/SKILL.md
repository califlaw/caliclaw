---
name: writing
description: Write documentation, emails, articles, content
---

## Principles
- Match the audience and tone requested
- Be clear and structured
- Use headings, lists, and short paragraphs
- Proofread before delivering

## Documentation
- Start with what it does, not how
- Include examples
- Keep it updated with code changes
