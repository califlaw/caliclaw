from __future__ import annotations

import asyncio
import time

import pytest

from core.queue import MessageQueue, QueuedMessage


@pytest.fixture
def queue():
    return MessageQueue(batch_delay=0.1, max_batch_size=5)


@pytest.mark.asyncio
async def test_single_message(queue):
    processed = []

    async def processor(session_id, batch):
        processed.append((session_id, [m.text for m in batch]))

    msg = QueuedMessage(text="Hello", sender="User")
    await queue.enqueue("sess-1", msg, processor)

    await asyncio.sleep(0.5)
    assert len(processed) == 1
    assert processed[0][0] == "sess-1"
    assert processed[0][1] == ["Hello"]


@pytest.mark.asyncio
async def test_message_batching(queue):
    processed = []

    async def processor(session_id, batch):
        processed.append((session_id, [m.text for m in batch]))

    # Send multiple messages quickly
    for i in range(3):
        msg = QueuedMessage(text=f"msg-{i}", sender="User")
        await queue.enqueue("sess-batch", msg, processor)

    await asyncio.sleep(0.5)
    # Should be batched into one call
    assert len(processed) == 1
    assert len(processed[0][1]) == 3


@pytest.mark.asyncio
async def test_format_single_message(queue):
    messages = [QueuedMessage(text="Hello world", sender="User")]
    result = queue.format_batch(messages)
    assert result == "Hello world"


@pytest.mark.asyncio
async def test_format_multiple_messages(queue):
    messages = [
        QueuedMessage(text="First", sender="User"),
        QueuedMessage(text="Second", sender="User"),
    ]
    result = queue.format_batch(messages)
    assert "Multiple messages" in result
    assert "First" in result
    assert "Second" in result


@pytest.mark.asyncio
async def test_format_with_media(queue):
    messages = [QueuedMessage(text="Check this", sender="User", media_path="/tmp/audio.ogg")]
    result = queue.format_batch(messages)
    assert "/tmp/audio.ogg" in result


def test_is_processing(queue):
    assert not queue.is_processing("sess-x")


def test_pending_count(queue):
    assert queue.pending_count("sess-x") == 0
