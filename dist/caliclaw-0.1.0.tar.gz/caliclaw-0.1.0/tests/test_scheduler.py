from __future__ import annotations

import time

import pytest
import pytest_asyncio

from automation.scheduler import HeartbeatManager, TaskScheduler
from core.agent import AgentPool


@pytest.mark.asyncio
async def test_setup_default_heartbeats(db):
    hm = HeartbeatManager(db)
    await hm.setup_default_heartbeats()

    # Should create 3 default heartbeats
    async with db.db.execute("SELECT COUNT(*) FROM tasks") as cur:
        row = await cur.fetchone()
    assert row[0] == 3


@pytest.mark.asyncio
async def test_heartbeats_not_duplicated(db):
    hm = HeartbeatManager(db)
    await hm.setup_default_heartbeats()
    await hm.setup_default_heartbeats()  # Call again

    async with db.db.execute("SELECT COUNT(*) FROM tasks") as cur:
        row = await cur.fetchone()
    assert row[0] == 3  # Still 3, not 6


@pytest.mark.asyncio
async def test_due_tasks_detected(db):
    past = time.time() - 100
    await db.create_task("due", "check", "cron", "* * * * *", next_run=past)

    due = await db.get_due_tasks()
    assert len(due) == 1
    assert due[0]["name"] == "due"


@pytest.mark.asyncio
async def test_task_update_after_run(db):
    task_id = await db.create_task("test", "check", "cron", "*/5 * * * *", next_run=time.time() - 10)

    future = time.time() + 300
    await db.update_task_after_run(task_id, next_run=future, result="All ok", status="active")

    # Should not be due anymore
    due = await db.get_due_tasks()
    assert len(due) == 0
