"""Telegram command and callback handlers.

Separated from bot.py for maintainability. All handlers are registered
via register_handlers(bot) called from caliclawBot._setup_handlers().
"""
from __future__ import annotations

import asyncio
import logging
import os
import subprocess
import signal as sig_mod
import uuid
from typing import TYPE_CHECKING

from aiogram import F, Router
from aiogram.enums import ParseMode
from aiogram.filters import Command, CommandStart
from aiogram.types import (
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
)

if TYPE_CHECKING:
    from telegram.bot import caliclawBot

logger = logging.getLogger(__name__)

router = Router()


def register_handlers(bot: caliclawBot) -> None:
    """Register all command, message, and callback handlers."""
    bot.dp.include_router(router)

    # ── /pair ──
    @router.message(Command("pair"))
    async def cmd_pair(message: Message) -> None:
        user_id = message.from_user.id if message.from_user else 0
        args = (message.text or "").split(maxsplit=1)
        if len(args) < 2:
            return
        code = args[1].strip().upper()
        expected = bot._pairing_code
        if not expected:
            return
        if code == expected:
            bot._pair_user(user_id)
            bot._pairing_code = None
            code_file = bot.settings.data_dir / "pairing_code.txt"
            code_file.unlink(missing_ok=True)
            await message.answer("🔱 Paired. You're the owner now.\n\nSend a message or /help")
            logger.info("Paired with user %d via code", user_id)

    # ── /start ──
    @router.message(CommandStart())
    async def cmd_start(message: Message) -> None:
        if not bot._check_allowed(message):
            return
        await message.answer(
            "🔱 **caliclaw** is ready\n\n"
            "Just send a message — I'll handle it.\n"
            'Type "stop" to abort.\n\n'
            "/fresh — new session\n"
            "/status — system info\n"
            "/agents — your agents\n"
            "/soul — who am I\n"
            "/help — all commands",
            parse_mode=ParseMode.MARKDOWN,
        )

    # ── /help ──
    @router.message(Command("help"))
    async def cmd_help(message: Message) -> None:
        if not bot._check_allowed(message):
            return
        await message.answer(
            "🔱 **caliclaw commands**\n\n"
            "**Session:**\n"
            "/fresh — new session\n"
            "/squeeze — compress context\n"
            "/reset — reset state\n\n"
            "**Agents:**\n"
            "/agents — list agents\n"
            "/spawn — create agent\n"
            "/kill — kill agent\n"
            "/promote — promote agent\n\n"
            "**Tasks:**\n"
            "/tasks — scheduled tasks\n"
            "/loop — autonomous loop\n"
            "/cron — schedule task\n"
            "/pause /resume — control tasks\n\n"
            "**System:**\n"
            "/status — system status\n"
            "/usage — token usage\n"
            "/model — switch model\n"
            "/memory — show memory\n"
            "/soul — show soul\n"
            "/skills — list skills\n"
            "/confirm — approve action\n"
            "/restart — restart bot",
            parse_mode=ParseMode.MARKDOWN,
        )

    # ── /fresh ──
    @router.message(Command("fresh"))
    async def cmd_fresh(message: Message) -> None:
        if not bot._check_allowed(message):
            return
        session_id = f"session-{uuid.uuid4().hex[:12]}"
        await bot.db.create_session(session_id, "main")
        bot._current_model = bot.settings.claude_default_model
        await message.answer(f"New session: `{session_id[:16]}...`", parse_mode=ParseMode.MARKDOWN)

    # ── /status ──
    @router.message(Command("status"))
    async def cmd_status(message: Message) -> None:
        if not bot._check_allowed(message):
            return
        from monitoring.tracking import UsageTracker
        tracker = UsageTracker(bot.db)
        summary = await tracker.get_today_summary()
        agents = await bot.db.list_agents()
        active = bot.pool.active_count
        limit_status = await tracker.check_limits()

        text = (
            f"🔱 **caliclaw Status**\n\n"
            f"Model: `{bot._current_model}`\n"
            f"Agents: {active}/{bot.settings.max_concurrent_agents} active, {len(agents)} total\n"
            f"Usage: {summary['total_percent']:.1f}% ({limit_status})\n"
            f"Requests today: {summary['total_requests']}\n"
            f"Queue: {'processing...' if bot.queue.is_processing('main') else 'empty'}"
        )
        await message.answer(text, parse_mode=ParseMode.MARKDOWN)

    # ── /usage ──
    @router.message(Command("usage"))
    async def cmd_usage(message: Message) -> None:
        if not bot._check_allowed(message):
            return
        from monitoring.tracking import UsageTracker
        tracker = UsageTracker(bot.db)
        summary = await tracker.get_today_summary()

        lines = [f"📊 **Usage today: {summary['total_percent']:.1f}%**\n"]
        for model, data in summary.get("by_model", {}).items():
            dur = data['duration_ms'] / 1000 if data['duration_ms'] else 0
            lines.append(f"  `{model}`: {data['count']} reqs, ~{data['percent']:.1f}%, {dur:.0f}s")

        limits = bot.settings
        lines.append(f"\nLimits: pause {limits.usage_pause_percent}% | emergency {limits.usage_emergency_percent}% | stop {limits.usage_stop_percent}%")
        await message.answer("\n".join(lines), parse_mode=ParseMode.MARKDOWN)

    # ── /model ──
    @router.message(Command("model"))
    async def cmd_model(message: Message) -> None:
        if not bot._check_allowed(message):
            return
        args = (message.text or "").split(maxsplit=1)
        if len(args) >= 2 and args[1].strip() in ("haiku", "sonnet", "opus"):
            bot._current_model = args[1].strip()
            await message.answer(f"Model: `{bot._current_model}`", parse_mode=ParseMode.MARKDOWN)
            return

        current = bot._current_model
        keyboard = InlineKeyboardMarkup(inline_keyboard=[[
            InlineKeyboardButton(
                text=f"{'> ' if current == m else ''}{m}",
                callback_data=f"model:{m}",
            )
            for m in ("haiku", "sonnet", "opus")
        ]])
        await message.answer(f"Current model: `{current}`", parse_mode=ParseMode.MARKDOWN, reply_markup=keyboard)

    # ── /memory ──
    @router.message(Command("memory"))
    async def cmd_memory(message: Message) -> None:
        if not bot._check_allowed(message):
            return
        from intelligence.memory import MemoryManager
        mm = MemoryManager()
        entries = mm.load_all()
        if not entries:
            await message.answer("Memory is empty.")
            return
        lines = ["📝 **Memory:**\n"]
        for e in entries:
            lines.append(f"• **{e.name}** ({e.type})\n  _{e.description}_")
        await message.answer("\n".join(lines)[:4000], parse_mode=ParseMode.MARKDOWN)

    # ── /soul ──
    @router.message(Command("soul"))
    async def cmd_soul(message: Message) -> None:
        if not bot._check_allowed(message):
            return
        soul_dir = bot.settings.agents_dir / "global" / "main"
        parts = []
        for name in ["SOUL.md", "IDENTITY.md", "USER.md"]:
            path = soul_dir / name
            if path.exists():
                content = path.read_text(encoding="utf-8").strip()
                if content:
                    parts.append(f"**{name}:**\n```\n{content[:800]}\n```")
        if parts:
            await message.answer("\n\n".join(parts)[:4000], parse_mode=ParseMode.MARKDOWN)
        else:
            await message.answer("No soul files found.")

    # ── /skills ──
    @router.message(Command("skills"))
    async def cmd_skills(message: Message) -> None:
        if not bot._check_allowed(message):
            return
        text, keyboard = bot._build_skills_message()
        await message.answer(text, parse_mode=ParseMode.MARKDOWN, reply_markup=keyboard)

    # ── /agents ──
    @router.message(Command("agents"))
    async def cmd_agents(message: Message) -> None:
        if not bot._check_allowed(message):
            return
        agents = await bot.db.list_agents()
        if not agents:
            await message.answer("No agents.")
            return
        lines = ["🤖 **Agents:**\n"]
        buttons = []
        for a in agents:
            status_icon = {"active": "🟢", "paused": "🟡", "killed": "🔴"}.get(a["status"], "⚪")
            lines.append(f"{status_icon} `{a['name']}` ({a['scope']}) — {a['status']}")
            if a["name"] != "main" and a["status"] == "active":
                buttons.append(InlineKeyboardButton(text=f"Kill {a['name']}", callback_data=f"kill:{a['name']}"))
        keyboard = InlineKeyboardMarkup(
            inline_keyboard=[buttons[i:i+2] for i in range(0, len(buttons), 2)]
        ) if buttons else None
        await message.answer("\n".join(lines), parse_mode=ParseMode.MARKDOWN, reply_markup=keyboard)

    # ── /spawn ──
    @router.message(Command("spawn"))
    async def cmd_spawn(message: Message) -> None:
        if not bot._check_allowed(message):
            return
        args = (message.text or "").split(maxsplit=2)
        if len(args) < 3:
            await message.answer(
                "Usage: /spawn `<name>` `<role description>`\n"
                "Example: /spawn researcher Research topics and gather info",
                parse_mode=ParseMode.MARKDOWN,
            )
            return
        name = args[1].strip()
        description = args[2].strip()

        from core.orchestrator import Orchestrator, SpawnRequest
        orch = Orchestrator(bot.db, bot.pool)
        request = SpawnRequest(
            name=name, role=description,
            soul=f"You are {name}. Your role: {description}.\nBe focused and concise.",
            identity=f"name: {name}\nrole: {description}",
            scope="ephemeral",
        )
        await orch.spawn_agent(request)
        await message.answer(f"🤖 Agent `{name}` created (ephemeral)", parse_mode=ParseMode.MARKDOWN)

    # ── /kill ──
    @router.message(Command("kill"))
    async def cmd_kill(message: Message) -> None:
        if not bot._check_allowed(message):
            return
        args = (message.text or "").split(maxsplit=1)
        if len(args) < 2:
            await message.answer("Usage: /kill `<agent name>`", parse_mode=ParseMode.MARKDOWN)
            return
        name = args[1].strip()
        if name == "main":
            await message.answer("Cannot kill the main agent.")
            return
        from core.orchestrator import Orchestrator
        orch = Orchestrator(bot.db, bot.pool)
        await orch.kill_agent(name, extract_knowledge=False)
        await message.answer(f"🔴 Agent `{name}` killed.", parse_mode=ParseMode.MARKDOWN)

    # ── /promote ──
    @router.message(Command("promote"))
    async def cmd_promote(message: Message) -> None:
        if not bot._check_allowed(message):
            return
        args = (message.text or "").split()
        if len(args) < 3:
            await message.answer("Usage: /promote `<name>` `<global|project>`", parse_mode=ParseMode.MARKDOWN)
            return
        name, scope = args[1], args[2]
        if scope not in ("global", "project"):
            await message.answer("Scope must be: global or project")
            return
        from core.orchestrator import Orchestrator
        orch = Orchestrator(bot.db, bot.pool)
        await orch.promote_agent(name, scope)
        await message.answer(f"⬆️ Agent `{name}` promoted to `{scope}`", parse_mode=ParseMode.MARKDOWN)

    # ── /tasks ──
    @router.message(Command("tasks"))
    async def cmd_tasks(message: Message) -> None:
        if not bot._check_allowed(message):
            return
        async with bot.db.db.execute("SELECT * FROM tasks ORDER BY status, next_run") as cur:
            rows = [dict(r) for r in await cur.fetchall()]
        if not rows:
            await message.answer("No tasks.")
            return
        lines = ["📋 **Tasks:**\n"]
        buttons = []
        for r in rows:
            icon = {"active": "🟢", "paused": "🟡", "completed": "✅", "failed": "🔴"}.get(r["status"], "⚪")
            lines.append(f"{icon} `#{r['id']}` **{r['name']}** — {r['schedule_type']}:{r['schedule_value']} ({r['status']})")
            if r["status"] == "active":
                buttons.append(InlineKeyboardButton(text=f"⏸ #{r['id']}", callback_data=f"task:pause:{r['id']}"))
            elif r["status"] == "paused":
                buttons.append(InlineKeyboardButton(text=f"▶ #{r['id']}", callback_data=f"task:resume:{r['id']}"))
        keyboard = InlineKeyboardMarkup(
            inline_keyboard=[buttons[i:i+3] for i in range(0, len(buttons), 3)]
        ) if buttons else None
        await message.answer("\n".join(lines)[:4000], parse_mode=ParseMode.MARKDOWN, reply_markup=keyboard)

    # ── /cron ──
    @router.message(Command("cron"))
    async def cmd_cron(message: Message) -> None:
        if not bot._check_allowed(message):
            return
        args = (message.text or "").split(maxsplit=2)
        if len(args) < 3:
            await message.answer(
                "Usage: /cron `<expression>` `<task>`\nExample: /cron `*/30 * * * *` Check server load",
                parse_mode=ParseMode.MARKDOWN,
            )
            return
        schedule, prompt = args[1], args[2]
        from croniter import croniter
        from datetime import datetime, timezone
        try:
            cron = croniter(schedule, datetime.now(timezone.utc))
            next_run = cron.get_next(datetime).timestamp()
        except (ValueError, KeyError):
            await message.answer("Invalid cron format.")
            return
        task_id = await bot.db.create_task(
            name=prompt[:30], prompt=prompt, schedule_type="cron",
            schedule_value=schedule, next_run=next_run, notify=True, model="haiku",
        )
        await message.answer(f"📋 Task `#{task_id}` created: `{schedule}`", parse_mode=ParseMode.MARKDOWN)

    # ── /pause ──
    @router.message(Command("pause"))
    async def cmd_pause(message: Message) -> None:
        if not bot._check_allowed(message):
            return
        args = (message.text or "").split()
        if len(args) < 2:
            await message.answer("Usage: /pause `<id>`", parse_mode=ParseMode.MARKDOWN)
            return
        try:
            task_id = int(args[1])
        except ValueError:
            await message.answer("ID must be a number.")
            return
        await bot.db.db.execute("UPDATE tasks SET status = 'paused' WHERE id = ?", (task_id,))
        await bot.db.db.commit()
        await message.answer(f"🟡 Task `#{task_id}` paused.", parse_mode=ParseMode.MARKDOWN)

    # ── /resume ──
    @router.message(Command("resume"))
    async def cmd_resume(message: Message) -> None:
        if not bot._check_allowed(message):
            return
        args = (message.text or "").split()
        if len(args) < 2:
            await message.answer("Usage: /resume `<id>`", parse_mode=ParseMode.MARKDOWN)
            return
        try:
            task_id = int(args[1])
        except ValueError:
            await message.answer("ID must be a number.")
            return
        await bot.db.db.execute("UPDATE tasks SET status = 'active' WHERE id = ?", (task_id,))
        await bot.db.db.commit()
        await message.answer(f"🟢 Task `#{task_id}` resumed.", parse_mode=ParseMode.MARKDOWN)

    # ── /loop ──
    @router.message(Command("loop"))
    async def cmd_loop(message: Message) -> None:
        if not bot._check_allowed(message):
            return
        args = (message.text or "").split(maxsplit=1)
        if len(args) < 2:
            await message.answer("Usage: /loop `<task description>`\nAgent will work in a loop until done.", parse_mode=ParseMode.MARKDOWN)
            return
        task_desc = args[1].strip()
        chat_id = message.chat.id

        await message.answer(f"🔄 Starting loop: _{task_desc}_", parse_mode=ParseMode.MARKDOWN)

        async def run_loop() -> None:
            from core.loops import AgentLoop, LoopConfig
            loop_runner = AgentLoop(bot.db, bot.pool)
            bot._active_loops[chat_id] = loop_runner
            system_prompt = bot.souls.load_soul("main")

            config = LoopConfig(
                agent_name="main", task_description=task_desc,
                model=bot._current_model, system_prompt=system_prompt, report_every=3,
            )

            async def on_progress(status) -> None:
                await bot.bot.send_message(chat_id, f"🔄 Iteration {status.iteration}/{status.total_iterations}")

            try:
                status = await loop_runner.run(config, on_progress=on_progress)
                if status.is_cancelled:
                    await bot.bot.send_message(chat_id, "🛑 Loop stopped by user.")
                elif status.is_complete:
                    await bot.bot.send_message(chat_id, f"✅ Loop completed in {status.iteration} iterations.")
                elif status.is_stuck:
                    await bot.bot.send_message(chat_id, f"⚠️ Loop stuck at iteration {status.iteration}.")
                elif status.error:
                    await bot.bot.send_message(chat_id, f"🔴 Loop stopped: {status.error}")
                if status.last_result and not status.is_cancelled:
                    await bot.bot.send_message(chat_id, status.last_result[:4000])
            finally:
                bot._active_loops.pop(chat_id, None)

        asyncio.create_task(run_loop())

    # ── /squeeze ──
    @router.message(Command("squeeze"))
    async def cmd_squeeze(message: Message) -> None:
        if not bot._check_allowed(message):
            return
        session = await bot.db.get_active_session("main")
        if not session:
            await message.answer("No active session.")
            return
        from intelligence.compaction import ConversationCompactor
        compactor = ConversationCompactor(bot.db, bot.pool)
        await message.answer("🏋️ Squeezing context...")
        compacted = await compactor.check_and_compact(session["id"])
        if compacted:
            await message.answer("✅ Lightweight now.")
        else:
            count = await bot.db.count_messages(session["id"])
            await message.answer(f"Already lean ({count} messages).")

    # ── /reset ──
    @router.message(Command("reset"))
    async def cmd_reset(message: Message) -> None:
        if not bot._check_allowed(message):
            return
        keyboard = InlineKeyboardMarkup(inline_keyboard=[
            [
                InlineKeyboardButton(text="Session", callback_data="reset:session"),
                InlineKeyboardButton(text="Agents", callback_data="reset:agents"),
            ],
            [
                InlineKeyboardButton(text="Tasks", callback_data="reset:tasks"),
                InlineKeyboardButton(text="ALL", callback_data="reset:all"),
            ],
        ])
        await message.answer("What to reset?", reply_markup=keyboard)

    # ── /confirm ──
    @router.message(Command("confirm"))
    async def cmd_confirm(message: Message) -> None:
        if not bot._check_allowed(message):
            return
        args = (message.text or "").split(maxsplit=1)
        if len(args) < 2:
            await message.answer("Usage: /confirm `<code>`", parse_mode=ParseMode.MARKDOWN)
            return
        code = args[1].strip()
        approval = await bot.db.get_pending_approval(code)
        if not approval:
            await message.answer("Code not found or already processed.")
            return
        await bot.db.resolve_approval(approval["id"], "approved", "telegram")
        await message.answer(f"✅ Approved: {approval['action']}")

    # ── /restart ──
    @router.message(Command("restart"))
    async def cmd_restart(message: Message) -> None:
        if not bot._check_allowed(message):
            return
        await message.answer("🔄 Restarting...")
        await bot.pool.kill_all()
        under_systemd = os.environ.get("INVOCATION_ID") is not None
        if not under_systemd:
            subprocess.Popen(
                ["bash", "-c", "sleep 3 && caliclaw start"],
                start_new_session=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            )
        os.kill(os.getpid(), sig_mod.SIGTERM)

    # ── Media handlers ──

    @router.message(F.voice | F.audio)
    async def handle_voice(message: Message) -> None:
        if not bot._check_allowed(message):
            return
        await bot._handle_audio(message)

    @router.message(F.document)
    async def handle_document(message: Message) -> None:
        if not bot._check_allowed(message):
            return
        await bot._handle_document(message)

    @router.message(F.photo)
    async def handle_photo(message: Message) -> None:
        if not bot._check_allowed(message):
            return
        import time
        caption = message.caption or "User sent a photo."
        photo = message.photo[-1]
        file = await bot.bot.get_file(photo.file_id)
        media_dir = bot.settings.workspace_dir / "media"
        media_dir.mkdir(parents=True, exist_ok=True)
        path = media_dir / f"photo_{int(time.time())}_{photo.file_id[-8:]}.jpg"
        await bot.bot.download_file(file.file_path, str(path))
        await bot._process_user_message(message, f"User sent a photo saved at {path}. Caption: {caption}", media_path=str(path))

    # ── Text handler ──

    @router.message(F.text)
    async def handle_text(message: Message) -> None:
        if not bot._check_allowed(message):
            return
        user_id = message.from_user.id if message.from_user else 0
        if not bot._check_rate_limit(user_id):
            await message.answer("⏳ Too many messages. Please wait.")
            return
        from telegram.bot import STOP_WORDS
        text_lower = (message.text or "").strip().lower()
        if text_lower in STOP_WORDS:
            await bot._handle_stop(message)
            return
        await bot._process_user_message(message, message.text or "")

    # ── Callback handler ──

    @router.callback_query()
    async def handle_callback(callback: CallbackQuery) -> None:
        data = callback.data or ""

        if data.startswith("approve:"):
            code = data.split(":", 1)[1]
            approval = await bot.db.get_pending_approval(code)
            if approval:
                await bot.db.resolve_approval(approval["id"], "approved", "telegram")
                await callback.answer("Approved!")
                if callback.message:
                    await callback.message.edit_text(f"✅ Approved: {approval['action']}")
            else:
                await callback.answer("Code not found.")

        elif data.startswith("deny:"):
            code = data.split(":", 1)[1]
            approval = await bot.db.get_pending_approval(code)
            if approval:
                await bot.db.resolve_approval(approval["id"], "denied", "telegram")
                await callback.answer("Denied.")
                if callback.message:
                    await callback.message.edit_text(f"❌ Denied: {approval['action']}")

        elif data.startswith("reset:"):
            target = data.split(":", 1)[1]
            msg_map = {
                "session": ("UPDATE sessions SET status = 'archived' WHERE status = 'active'", "Sessions archived."),
                "agents": ("UPDATE agents SET status = 'killed' WHERE scope = 'ephemeral' AND status = 'active'", "Ephemeral agents killed."),
                "tasks": ("UPDATE tasks SET status = 'paused'", "All tasks paused."),
            }
            if target == "all":
                for sql, _ in msg_map.values():
                    await bot.db.db.execute(sql)
                await bot.db.db.commit()
                msg = "Full reset done."
            elif target in msg_map:
                await bot.db.db.execute(msg_map[target][0])
                await bot.db.db.commit()
                msg = msg_map[target][1]
            else:
                msg = "Unknown target."
            await callback.answer(msg)
            if callback.message:
                await callback.message.edit_text(f"🔄 {msg}")

        elif data.startswith("model:"):
            model = data.split(":", 1)[1]
            if model in ("haiku", "sonnet", "opus"):
                if model == bot._current_model:
                    await callback.answer(f"Already on {model}")
                    return
                bot._current_model = model
                await callback.answer(f"Switched to {model}")
                if callback.message:
                    keyboard = InlineKeyboardMarkup(inline_keyboard=[[
                        InlineKeyboardButton(text=f"{'> ' if model == m else ''}{m}", callback_data=f"model:{m}")
                        for m in ("haiku", "sonnet", "opus")
                    ]])
                    await callback.message.edit_text(f"Current model: `{model}`", parse_mode=ParseMode.MARKDOWN, reply_markup=keyboard)

        elif data.startswith("skill:"):
            skill_name = data.split(":", 1)[1]
            config_file = bot.settings.project_root / "data" / "enabled_skills.txt"
            enabled = set()
            if config_file.exists():
                enabled = {l.strip() for l in config_file.read_text().split("\n") if l.strip()}
            if skill_name in enabled:
                enabled.discard(skill_name)
                action = "off"
            else:
                enabled.add(skill_name)
                action = "on"
            config_file.parent.mkdir(parents=True, exist_ok=True)
            config_file.write_text("\n".join(sorted(enabled)) + "\n")
            await callback.answer(f"{skill_name}: {action}")
            if callback.message:
                text, keyboard = bot._build_skills_message()
                await callback.message.edit_text(text, parse_mode=ParseMode.MARKDOWN, reply_markup=keyboard)

        elif data.startswith("kill:"):
            name = data.split(":", 1)[1]
            if name == "main":
                await callback.answer("Cannot kill main agent.")
                return
            from core.orchestrator import Orchestrator
            orch = Orchestrator(bot.db, bot.pool)
            await orch.kill_agent(name, extract_knowledge=False)
            await callback.answer(f"Agent {name} killed.")
            if callback.message:
                await callback.message.edit_text(f"🔴 Agent `{name}` killed.", parse_mode=ParseMode.MARKDOWN)

        elif data.startswith("task:"):
            parts = data.split(":")
            if len(parts) == 3:
                action, task_id_str = parts[1], parts[2]
                try:
                    task_id = int(task_id_str)
                except ValueError:
                    await callback.answer("Invalid task ID.")
                    return
                if action == "pause":
                    await bot.db.db.execute("UPDATE tasks SET status = 'paused' WHERE id = ?", (task_id,))
                    await bot.db.db.commit()
                    await callback.answer(f"Task #{task_id} paused.")
                elif action == "resume":
                    await bot.db.db.execute("UPDATE tasks SET status = 'active' WHERE id = ?", (task_id,))
                    await bot.db.db.commit()
                    await callback.answer(f"Task #{task_id} resumed.")
                if callback.message:
                    await callback.message.edit_text(
                        f"{'🟡' if action == 'pause' else '🟢'} Task `#{task_id}` {action}d.",
                        parse_mode=ParseMode.MARKDOWN,
                    )
