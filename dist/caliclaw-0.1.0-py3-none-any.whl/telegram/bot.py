"""caliclaw Telegram bot — core class.

Command and callback handlers are in telegram/handlers.py.
"""
from __future__ import annotations

import asyncio
import logging
import re
import time
import uuid
from typing import Optional

import aiohttp
from aiogram import Bot, Dispatcher
from aiogram.enums import ChatAction, ParseMode
from aiogram.types import (
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
)

from core.agent import AgentConfig, AgentPool, AgentResult
from core.config import get_settings
from core.db import Database
from core.queue import MessageQueue, QueuedMessage
from core.souls import SoulLoader

logger = logging.getLogger(__name__)

STOP_WORDS = {"стоп", "stop"}

_RATE_LIMIT = 15
_RATE_WINDOW = 60.0


class caliclawBot:
    def __init__(self, db: Database):
        self.settings = get_settings()
        self.bot = Bot(token=self.settings.telegram_bot_token)
        self.dp = Dispatcher()
        self.db = db
        self.pool = AgentPool()
        self.queue = MessageQueue()
        self.souls = SoulLoader()
        self._typing_tasks: dict[int, asyncio.Task] = {}
        self._current_model: str = self.settings.claude_default_model
        self._active_loops: dict[int, "AgentLoop"] = {}
        self._rate_history: dict[int, list[float]] = {}
        self._pairing_code: str | None = self._load_pairing_code()

        self._setup_handlers()

    def _setup_handlers(self) -> None:
        from telegram.handlers import register_handlers
        register_handlers(self)

    # ── Auth & pairing ──

    def _check_allowed(self, message: Message) -> bool:
        if not self.settings.telegram_allowed_users:
            return False
        user_id = message.from_user.id if message.from_user else 0
        return user_id in self.settings.telegram_allowed_users

    def _load_pairing_code(self) -> str | None:
        code_file = self.settings.data_dir / "pairing_code.txt"
        if code_file.exists():
            return code_file.read_text().strip().upper()
        return None

    def _pair_user(self, user_id: int) -> None:
        self.settings.telegram_allowed_users = [user_id]
        env_file = self.settings.project_root / ".env"
        if env_file.exists():
            content = env_file.read_text()
            if "TELEGRAM_ALLOWED_USERS" not in content:
                content += f"\nTELEGRAM_ALLOWED_USERS={user_id}\n"
            else:
                content = re.sub(r"TELEGRAM_ALLOWED_USERS=.*", f"TELEGRAM_ALLOWED_USERS={user_id}", content)
            env_file.write_text(content)
        logger.info("Paired with user %d", user_id)

    def _check_rate_limit(self, user_id: int) -> bool:
        now = time.time()
        history = self._rate_history.get(user_id, [])
        history = [t for t in history if now - t < _RATE_WINDOW]
        history.append(now)
        self._rate_history[user_id] = history
        return len(history) <= _RATE_LIMIT

    # ── Skills helper ──

    def _build_skills_message(self) -> tuple[str, InlineKeyboardMarkup | None]:
        skills_dir = self.settings.skills_dir
        if not skills_dir or not skills_dir.exists():
            return "No skills found.", None

        skills = [d.name for d in skills_dir.iterdir() if d.is_dir() and (d / "SKILL.md").exists()]
        if not skills:
            return "No skills. Create: `skills/<name>/SKILL.md`", None

        config_file = self.settings.project_root / "data" / "enabled_skills.txt"
        enabled = set()
        if config_file.exists():
            enabled = {l.strip() for l in config_file.read_text().split("\n") if l.strip()}

        lines = ["🛠 **Skills:**\n"]
        buttons = []
        for s in sorted(skills):
            is_on = s in enabled
            icon = "🟢" if is_on else "⚪"
            lines.append(f"{icon} `{s}`")
            buttons.append(InlineKeyboardButton(text=f"{'🟢 ' if is_on else '⚪ '}{s}", callback_data=f"skill:{s}"))

        keyboard = InlineKeyboardMarkup(inline_keyboard=[buttons[i:i+2] for i in range(0, len(buttons), 2)])
        return "\n".join(lines), keyboard

    # ── Stop handler ──

    async def _handle_stop(self, message: Message) -> None:
        chat_id = message.chat.id
        sender = message.from_user.full_name if message.from_user else "Unknown"
        stopped = []

        loop_runner = self._active_loops.get(chat_id)
        if loop_runner:
            loop_runner.cancel()
            stopped.append("loop")

        active_before = self.pool.active_count
        if active_before > 0:
            await self.pool.kill_all()
            stopped.append(f"{active_before} agent(s)")

        typing_task = self._typing_tasks.pop(chat_id, None)
        if typing_task:
            typing_task.cancel()

        stop_detail = ", ".join(stopped) if stopped else "nothing active"
        logger.info("STOP command from %s (chat %d): %s", sender, chat_id, stop_detail)

        session = await self.db.get_active_session("main")
        if session:
            await self.db.save_message(
                role="system",
                content=f"[STOP] User issued stop command. Stopped: {stop_detail}",
                session_id=session["id"],
            )

        if stopped:
            await message.answer(f"🛑 Stopped: {', '.join(stopped)}")
        else:
            await message.answer("🛑 Nothing to stop — no agents running.")

    # ── Media handlers ──

    async def _handle_audio(self, message: Message) -> None:
        voice = message.voice or message.audio
        if not voice:
            return

        file = await self.bot.get_file(voice.file_id)
        media_dir = self.settings.workspace_dir / "media"
        media_dir.mkdir(parents=True, exist_ok=True)
        ext = "ogg" if message.voice else "mp3"
        path = media_dir / f"audio_{int(time.time())}_{voice.file_id[-8:]}.{ext}"
        await self.bot.download_file(file.file_path, str(path))

        try:
            from media.transcribe import transcribe_audio
            text = await transcribe_audio(str(path))
            if not text:
                await message.answer("Could not transcribe audio.")
                return
            await self._process_user_message(message, text)
        except (OSError, RuntimeError) as e:
            logger.exception("Transcription failed")
            await message.answer(f"Transcription error: {e}")

    async def _handle_document(self, message: Message) -> None:
        doc = message.document
        if not doc:
            return
        file = await self.bot.get_file(doc.file_id)
        media_dir = self.settings.workspace_dir / "media"
        media_dir.mkdir(parents=True, exist_ok=True)
        path = media_dir / f"doc_{int(time.time())}_{doc.file_name or 'file'}"
        await self.bot.download_file(file.file_path, str(path))

        caption = message.caption or f"User sent a document: {doc.file_name}"
        await self._process_user_message(message, f"{caption}\nFile saved at: {path}", media_path=str(path))

    # ── Message processing ──

    async def _process_user_message(
        self, message: Message, text: str, media_path: Optional[str] = None,
    ) -> None:
        chat_id = message.chat.id
        sender = message.from_user.full_name if message.from_user else "User"

        from safety.input_filter import check_injection
        warning = check_injection(text)
        if warning:
            logger.warning("Injection attempt from %s: %s", sender, warning)

        session = await self.db.get_active_session("main")
        if not session:
            session_id = f"session-{uuid.uuid4().hex[:12]}"
            await self.db.create_session(session_id, "main")
        else:
            session_id = session["id"]

        await self.db.save_message(
            role="user", content=text, session_id=session_id,
            telegram_message_id=message.message_id,
        )

        queued = QueuedMessage(
            text=text, sender=sender,
            telegram_message_id=message.message_id, media_path=media_path,
        )
        await self.queue.enqueue(
            session_id, queued,
            lambda sid, batch: self._run_agent(chat_id, sid, batch),
        )

    async def _run_agent(
        self, chat_id: int, session_id: str, batch: list[QueuedMessage]
    ) -> None:
        typing_task = asyncio.create_task(self._keep_typing(chat_id))

        try:
            prompt = self.queue.format_batch(batch)
            system_prompt = self.souls.load_soul("main")
            session = await self.db.get_session(session_id)
            claude_session_id = session.get("claude_session_id") if session else None

            config = AgentConfig(
                name="main", model=self._current_model, system_prompt=system_prompt,
                continue_session=claude_session_id is not None,
                session_id=claude_session_id, working_dir=self.settings.workspace_dir,
            )

            response_msg: Optional[Message] = None
            accumulated_text = ""
            last_edit_time = 0.0

            async def on_chunk(chunk: str) -> None:
                nonlocal response_msg, accumulated_text, last_edit_time
                accumulated_text += chunk
                now = time.time()
                if now - last_edit_time < 2.0:
                    return
                display_text = accumulated_text[:4000]
                try:
                    if response_msg is None:
                        response_msg = await self.bot.send_message(chat_id, display_text or "...")
                    elif display_text != (response_msg.text or ""):
                        await response_msg.edit_text(display_text)
                    last_edit_time = now
                except (aiohttp.ClientError, asyncio.TimeoutError):
                    pass

            result = await self.pool.run_streaming(config, prompt, on_chunk)

            typing_task.cancel()
            final_text = result.text or accumulated_text or "No response."
            if result.error:
                final_text = f"⚠️ Error: {result.error}\n\n{final_text}"
            if len(final_text) > 4096:
                final_text = final_text[:4090] + "\n..."

            try:
                if response_msg is None:
                    await self.bot.send_message(chat_id, final_text)
                elif final_text != (response_msg.text or ""):
                    await response_msg.edit_text(final_text)
            except (aiohttp.ClientError, asyncio.TimeoutError) as e:
                logger.warning("Failed to send final response: %s", e)
                await self.bot.send_message(chat_id, final_text)

            await self.db.save_message(role="assistant", content=result.text or "", session_id=session_id)
            if result.session_id:
                await self.db.update_session(session_id, claude_session_id=result.session_id)
            await self.db.log_usage(
                agent_name="main", model=config.model,
                duration_ms=result.duration_ms, session_id=session_id,
            )

        except (aiohttp.ClientError, asyncio.TimeoutError, OSError) as e:
            typing_task.cancel()
            logger.exception("Agent run failed: %s", e)
            await self.bot.send_message(chat_id, "⚠️ Processing error. Please try again.")

    async def _keep_typing(self, chat_id: int) -> None:
        try:
            while True:
                await self.bot.send_chat_action(chat_id, ChatAction.TYPING)
                await asyncio.sleep(4)
        except asyncio.CancelledError:
            pass

    # ── Notifications ──

    async def send_notification(self, chat_id: int, text: str) -> None:
        await self.bot.send_message(chat_id, text)

    async def send_approval_request(
        self, chat_id: int, approval_id: str, agent_name: str,
        action: str, reason: str, code: str, level: str,
    ) -> None:
        text = (
            f"🔐 **Approval Request**\n\n"
            f"Agent: `{agent_name}`\n"
            f"Action: `{action}`\n"
            f"Reason: {reason}\n"
        )
        if level == "confirm_terminal":
            text += f"\n⚠️ Critical action!\nEnter code: `/confirm {code}`"
            await self.bot.send_message(chat_id, text, parse_mode=ParseMode.MARKDOWN)
        else:
            keyboard = InlineKeyboardMarkup(inline_keyboard=[[
                InlineKeyboardButton(text="✅ Approve", callback_data=f"approve:{code}"),
                InlineKeyboardButton(text="❌ Deny", callback_data=f"deny:{code}"),
            ]])
            await self.bot.send_message(chat_id, text, parse_mode=ParseMode.MARKDOWN, reply_markup=keyboard)

    # ── Start / Stop ──

    async def start(self) -> None:
        logger.info("Starting caliclaw Telegram bot...")
        from aiogram.types import BotCommand
        await self.bot.set_my_commands([
            BotCommand(command="fresh", description="New session"),
            BotCommand(command="squeeze", description="Compress context"),
            BotCommand(command="reset", description="Reset state"),
            BotCommand(command="agents", description="List agents"),
            BotCommand(command="spawn", description="Create agent"),
            BotCommand(command="kill", description="Kill agent"),
            BotCommand(command="promote", description="Promote agent"),
            BotCommand(command="tasks", description="Scheduled tasks"),
            BotCommand(command="loop", description="Autonomous loop"),
            BotCommand(command="cron", description="Schedule task"),
            BotCommand(command="pause", description="Pause task"),
            BotCommand(command="resume", description="Resume task"),
            BotCommand(command="status", description="System status"),
            BotCommand(command="usage", description="Token usage"),
            BotCommand(command="model", description="Switch model"),
            BotCommand(command="memory", description="Show memory"),
            BotCommand(command="soul", description="Show soul"),
            BotCommand(command="skills", description="List skills"),
            BotCommand(command="confirm", description="Approve action"),
            BotCommand(command="restart", description="Restart bot"),
            BotCommand(command="help", description="All commands"),
        ])

        retry_delay = 5
        attempt = 0
        while True:
            try:
                attempt += 1
                if attempt > 1:
                    logger.info("Telegram reconnect attempt #%d", attempt)
                await self.dp.start_polling(self.bot)
                break
            except (aiohttp.ClientError, asyncio.TimeoutError, ConnectionError) as e:
                logger.warning("Telegram connection lost: %s. Retrying in %ds...", e, retry_delay)
                await asyncio.sleep(retry_delay)
                retry_delay = min(retry_delay * 2, 60)

    async def stop(self) -> None:
        await self.dp.stop_polling()
        await self.pool.kill_all()
        await self.bot.session.close()
