from __future__ import annotations

import base64
import json
import logging
import os
from pathlib import Path
from typing import Dict, Optional

from cryptography.fernet import Fernet, InvalidToken
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

from core.config import get_settings

logger = logging.getLogger(__name__)


class Vault:
    """Encrypted credential storage using Fernet (AES-128-CBC)."""

    def __init__(self, vault_path: Optional[Path] = None, key_path: Optional[Path] = None):
        settings = get_settings()
        self._vault_path = vault_path or (settings.project_root / "vault" / "secrets.enc")
        self._key_path = key_path or settings.vault_key_path
        self._fernet: Optional[Fernet] = None
        self._secrets: Dict[str, str] = {}

    def _derive_key(self, password: bytes, salt: bytes) -> bytes:
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt,
            iterations=480000,
        )
        return base64.urlsafe_b64encode(kdf.derive(password))

    def initialize(self, master_password: str) -> None:
        """Initialize vault with a master password."""
        self._key_path.parent.mkdir(parents=True, exist_ok=True)
        self._vault_path.parent.mkdir(parents=True, exist_ok=True)

        salt = os.urandom(16)
        key = self._derive_key(master_password.encode(), salt)

        # Save salt + key indicator
        self._key_path.write_bytes(salt)
        self._key_path.chmod(0o600)

        self._fernet = Fernet(key)
        self._secrets = {}
        self._save()
        logger.info("Vault initialized at %s", self._vault_path)

    def unlock(self, master_password: str) -> bool:
        """Unlock vault with master password. Returns True if successful."""
        try:
            if not self._key_path.exists():
                return False

            salt = self._key_path.read_bytes()
            key = self._derive_key(master_password.encode(), salt)
            self._fernet = Fernet(key)

            if self._vault_path.exists():
                encrypted = self._vault_path.read_bytes()
                decrypted = self._fernet.decrypt(encrypted)
                self._secrets = json.loads(decrypted)
            else:
                self._secrets = {}

            logger.info("Vault unlocked")
            return True
        except (ValueError, InvalidToken, OSError) as e:
            logger.error("Failed to unlock vault: %s", e)
            self._fernet = None
            return False

    def is_unlocked(self) -> bool:
        return self._fernet is not None

    def get(self, name: str) -> Optional[str]:
        if not self.is_unlocked():
            raise RuntimeError("Vault is locked")
        return self._secrets.get(name)

    def set(self, name: str, value: str) -> None:
        if not self.is_unlocked():
            raise RuntimeError("Vault is locked")
        self._secrets[name] = value
        self._save()
        logger.info("Vault: stored secret '%s'", name)

    def delete(self, name: str) -> bool:
        if not self.is_unlocked():
            raise RuntimeError("Vault is locked")
        if name in self._secrets:
            del self._secrets[name]
            self._save()
            return True
        return False

    def list_keys(self) -> list[str]:
        if not self.is_unlocked():
            raise RuntimeError("Vault is locked")
        return list(self._secrets.keys())

    def _save(self) -> None:
        assert self._fernet is not None
        data = json.dumps(self._secrets).encode()
        encrypted = self._fernet.encrypt(data)
        self._vault_path.write_bytes(encrypted)
        self._vault_path.chmod(0o600)
