from __future__ import annotations

import os
from pathlib import Path
from typing import List

from pydantic_settings import BaseSettings
from pydantic import Field, field_validator


def _project_root() -> Path:
    """Resolve project root: env var > cwd > package dir."""
    env = os.environ.get("CALICLAW_HOME") or os.environ.get("PROJECT_ROOT")
    if env:
        return Path(env).resolve()
    # If cwd has .env or agents/, we're in a caliclaw project
    cwd = Path.cwd()
    if (cwd / ".env").exists() or (cwd / "agents").exists():
        return cwd
    # Fallback to package directory (git clone usage)
    return Path(__file__).resolve().parent.parent


class Settings(BaseSettings):
    model_config = {"env_file": str(_project_root() / ".env"), "extra": "ignore"}

    # Telegram
    telegram_bot_token: str = ""
    telegram_allowed_users: List[int] = Field(default_factory=list)

    @field_validator("telegram_allowed_users", mode="before")
    @classmethod
    def parse_allowed_users(cls, v):
        if isinstance(v, str):
            return [int(x.strip()) for x in v.split(",") if x.strip()]
        if isinstance(v, int):
            return [v]
        return v

    # Claude Code
    claude_binary: str = "claude"
    claude_default_model: str = "sonnet"

    # Paths
    project_root: Path = Field(default_factory=_project_root)
    data_dir: Path = Field(default_factory=lambda: _project_root() / "data")
    workspace_dir: Path = Field(default_factory=lambda: _project_root() / "workspace")
    agents_dir: Path = Field(default_factory=lambda: _project_root() / "agents")
    skills_dir: Path = Field(default_factory=lambda: _project_root() / "skills")
    memory_dir: Path = Field(default_factory=lambda: _project_root() / "memory")

    # Limits
    max_concurrent_agents: int = 3
    max_loop_iterations: int = 20
    max_loop_duration_minutes: int = 120
    usage_pause_percent: int = 80
    usage_emergency_percent: int = 90
    usage_stop_percent: int = 95

    # Heartbeat cron expressions
    heartbeat_quick_cron: str = "*/5 * * * *"
    heartbeat_review_cron: str = "*/30 * * * *"
    heartbeat_morning_cron: str = "0 9 * * *"
    heartbeat_dream_cron: str = "0 3 * * *"

    # Whisper
    whisper_cpp_path: str = "/usr/local/bin/whisper-cpp"
    whisper_model_path: str = str(_project_root() / "models" / "ggml-base.bin")

    # Vault
    vault_key_path: Path = Path.home() / ".caliclaw" / "vault.key"

    # Dashboard
    dashboard_port: int = 8080
    dashboard_enabled: bool = True

    # Timezone
    tz: str = "Europe/Moscow"

    # Logging
    log_level: str = "INFO"

    def ensure_dirs(self) -> None:
        for d in (
            self.data_dir,
            self.workspace_dir,
            self.workspace_dir / "conversations",
            self.workspace_dir / "media",
            self.workspace_dir / "ipc",
            self.workspace_dir / "projects",
            self.agents_dir,
            self.skills_dir,
            self.memory_dir,
            self.project_root / "logs",
        ):
            d.mkdir(parents=True, exist_ok=True)


_settings: Settings | None = None


def get_settings() -> Settings:
    global _settings
    if _settings is None:
        _settings = Settings()
    return _settings


def reset_settings() -> None:
    global _settings
    _settings = None
