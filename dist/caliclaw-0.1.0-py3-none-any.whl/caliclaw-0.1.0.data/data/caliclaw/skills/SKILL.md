---
name: browser
description: Browser automation — open pages, click, fill forms, scrape
requires: [playwright]
---

## Setup
Uses Playwright for headless browser automation.
Install: `playwright install chromium`

## When to use
- Fill out web forms
- Scrape dynamic pages (JS-rendered content)
- Take screenshots of websites
- Automate web workflows (login, submit, download)
- Test web applications

## When NOT to use
- Simple page reading → use WebFetch instead
- Search → use WebSearch instead
- API calls → use curl/requests instead

## How to use
```python
from playwright.async_api import async_playwright

async with async_playwright() as p:
    browser = await p.chromium.launch(headless=True)
    page = await browser.new_page()
    await page.goto("https://example.com")
    
    # Screenshots
    await page.screenshot(path="screenshot.png")
    
    # Click
    await page.click("button#submit")
    
    # Fill forms
    await page.fill("input[name='email']", "user@example.com")
    
    # Get text
    text = await page.text_content("div.result")
    
    # Wait for element
    await page.wait_for_selector("div.loaded")
    
    await browser.close()
```

## Rules
- Always use headless=True
- Set reasonable timeouts (30s max)
- Close browser after use
- Don't store cookies or credentials in code
- Screenshot before and after important actions for verification
