# User Profile
<!-- This file is updated automatically as caliclaw learns about the user -->
<!-- Edit manually to set initial preferences -->

name: master
role: 
preferences:
  language: ru
  communication_style: direct
  timezone: Europe/Moscow
