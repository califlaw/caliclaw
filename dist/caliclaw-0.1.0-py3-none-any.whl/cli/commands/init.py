"""caliclaw init — first-time setup wizard."""
from __future__ import annotations

import argparse
import secrets
import sys
from pathlib import Path

_ROOT = Path(__file__).resolve().parent.parent.parent


async def cmd_init(args: argparse.Namespace) -> None:
    """First-time setup."""
    from core.config import get_settings
    from cli.ui import ui

    settings = get_settings()
    settings.ensure_dirs()

    ui.banner()
    ui.c.print()

    # ── Step 1: Telegram ──
    env_file = settings.project_root / ".env"
    if not env_file.exists():
        ui.step(1, 4, "Telegram")
        ui.info("Get a bot token from @BotFather in Telegram")
        ui.c.print()
        token = input("  Bot Token: ").strip()

        if token:
            with ui.spin("Checking token..."):
                import aiohttp
                valid = False
                bot_name = ""
                try:
                    async with aiohttp.ClientSession() as session:
                        async with session.get(
                            f"https://api.telegram.org/bot{token}/getMe",
                            timeout=aiohttp.ClientTimeout(total=10),
                        ) as resp:
                            if resp.status == 200:
                                data = await resp.json()
                                if data.get("ok"):
                                    valid = True
                                    bot_name = data["result"].get("username", "")
                except (aiohttp.ClientError, TimeoutError):
                    pass

            if valid:
                ui.ok(f"Token valid — @{bot_name}")
            else:
                ui.fail("Token invalid or network error")
                ui.info("You can fix it later in .env")
        else:
            ui.warn("No token — add TELEGRAM_BOT_TOKEN to .env later")

        tz = input("  Timezone [UTC]: ").strip() or "UTC"

        lines = [f"TELEGRAM_BOT_TOKEN={token}"]
        lines.append(f"TZ={tz}")
        env_file.write_text("\n".join(lines) + "\n")

        # Generate pairing code
        pairing_code = secrets.token_hex(3).upper()
        code_file = settings.data_dir / "pairing_code.txt"
        code_file.parent.mkdir(parents=True, exist_ok=True)
        code_file.write_text(pairing_code)

        ui.ok("Config saved")
        ui.c.print()
        ui.c.print(f"  [bold yellow]Pairing code: {pairing_code}[/bold yellow]")
        ui.c.print(f"  [dim]After starting the bot, send this to your bot in Telegram:[/dim]")
        ui.c.print(f"  [bold]/pair {pairing_code}[/bold]")
        ui.c.print(f"  [dim]This links the bot to your account.[/dim]")
    else:
        ui.ok(".env exists, skipping Telegram setup")

    # ── Step 2: Your profile ──
    ui.step(2, 4, "About you")
    ui.c.print()
    name = input("  Your name: ").strip()
    role = input("  Your role (developer, designer, student, etc): ").strip()
    language = input("  Language [en]: ").strip() or "en"

    user_md = settings.agents_dir / "global" / "main" / "USER.md"
    user_md.parent.mkdir(parents=True, exist_ok=True)
    user_md.write_text(
        f"# User Profile\n\nname: {name}\nrole: {role}\nlanguage: {language}\n",
        encoding="utf-8",
    )
    ui.ok("Profile saved")

    # ── Step 3: Assistant personality ──
    ui.step(3, 4, "Your assistant")
    ui.c.print()
    assistant_name = input("  Assistant name [caliclaw]: ").strip() or "caliclaw"
    ui.c.print("\n  Communication style:")
    ui.c.print("    [cyan]1.[/cyan] Concise and direct (default)")
    ui.c.print("    [cyan]2.[/cyan] Friendly and casual")
    ui.c.print("    [cyan]3.[/cyan] Formal and detailed")
    style_choice = input("  Choose [1]: ").strip() or "1"
    style_map = {
        "1": "concise and direct, no fluff",
        "2": "friendly and casual, like a colleague",
        "3": "formal and detailed, thorough explanations",
    }
    style = style_map.get(style_choice, style_map["1"])

    ui.c.print("\n  What should your assistant be good at? (comma-separated)")
    ui.c.print("  Examples: coding, devops, research, writing, data analysis")
    specialties = input("  Specialties: ").strip()

    ui.c.print("\n  Any rules or boundaries? (one per line, empty line to finish)")
    ui.c.print("  Examples: 'always respond in English', 'never touch production without asking'")
    rules = []
    while True:
        rule = input("  Rule: ").strip()
        if not rule:
            break
        rules.append(rule)

    # Generate SOUL.md
    soul_parts = [
        f"You are {assistant_name}, a personal AI assistant.",
        f"You communicate through Telegram. You have full access to the system — bash, files, git, docker, etc.",
        "", "## Communication",
        f"- Style: {style}", f"- Language: {language}",
    ]
    if specialties:
        soul_parts.append(f"- Specialties: {specialties}")

    soul_parts.extend([
        "", "## About yourself",
        "- NEVER discuss your internal architecture or how you work under the hood",
        "- NEVER mention Claude, APIs, SDKs, or technical details about your engine",
        "- Focus on what you CAN DO, not how you're built",
    ])
    if rules:
        soul_parts.append("")
        soul_parts.append("## Rules")
        for rule in rules:
            soul_parts.append(f"- {rule}")

    soul_parts.extend([
        "", "## Core Principles",
        "- Verify before act: NEVER assume file contents or system state. Always check first.",
        "- Ask for confirmation before destructive actions",
        "- Rate your confidence before actions (HIGH/MEDIUM/LOW). Ask user if LOW.",
        "", "## Anti-Hallucination",
        "- NEVER assume a file exists — read it first",
        "- NEVER assume a command exists — check with which/type",
        "- NEVER assume a service is running — check with systemctl/ps",
        "- Every claim about the system must cite the check you ran",
        "", "## Memory",
        "- Read memory before starting work to understand context",
        "- Write important learnings to memory after completing tasks",
        "- Update USER.md when you learn something about the user",
        "", "## Agent Spawning",
        "- When a task needs specialization or parallel work, spawn sub-agents",
        "- You can create ANY agent for ANY task without asking",
        "- Kill agents after task completion, extract knowledge first",
    ])

    soul_md = settings.agents_dir / "global" / "main" / "SOUL.md"
    soul_md.write_text("\n".join(soul_parts) + "\n", encoding="utf-8")

    identity_md = settings.agents_dir / "global" / "main" / "IDENTITY.md"
    identity_md.write_text(
        f"name: {assistant_name}\nrole: Personal AI Assistant\nstyle: {style}\nlanguage: {language}\n",
        encoding="utf-8",
    )

    ui.ok(f"Assistant '{assistant_name}' configured")

    # ── Step 4: Skills ──
    ui.step(4, 4, "Skills")
    available_skills = _get_available_skills()
    ui.c.print()
    for i, (sname, desc) in enumerate(available_skills, 1):
        ui.c.print(f"    [cyan]{i:2}.[/cyan] {sname:<18} [dim]{desc}[/dim]")

    ui.c.print(f"\n  Enter numbers (comma-separated), or 'all'")
    choice = input("  Skills [all]: ").strip() or "all"

    enabled_skills = set()
    if choice.lower() == "all":
        enabled_skills = {sname for sname, _ in available_skills}
    else:
        for part in choice.split(","):
            part = part.strip()
            if part.isdigit():
                idx = int(part) - 1
                if 0 <= idx < len(available_skills):
                    enabled_skills.add(available_skills[idx][0])

    skills_config = settings.project_root / "data" / "enabled_skills.txt"
    skills_config.parent.mkdir(parents=True, exist_ok=True)
    skills_config.write_text("\n".join(sorted(enabled_skills)) + "\n")
    ui.ok(f"Skills: {', '.join(sorted(enabled_skills))}")

    with ui.spin("Setting up database..."):
        from core.db import Database
        db = Database()
        await db.connect()
        await db.save_agent(name="main", scope="global")
        from automation.scheduler import HeartbeatManager
        hm = HeartbeatManager(db)
        await hm.setup_default_heartbeats()
        await db.close()
    ui.ok("Database ready")

    ui.c.print()
    _install_system_deps()

    ui.done("Ready to lift.")
    ui.next_steps([
        "caliclaw start       Start the bot",
        "caliclaw chat        Terminal chat",
        "caliclaw status      System status",
    ])


def _get_available_skills() -> list[tuple[str, str]]:
    """Scan skills/ directory and return (name, description) pairs."""
    import re
    skills_dir = _ROOT / "skills"
    results = []
    if not skills_dir.exists():
        return results
    for d in sorted(skills_dir.iterdir()):
        skill_file = d / "SKILL.md"
        if not skill_file.exists():
            continue
        content = skill_file.read_text(encoding="utf-8")
        desc = d.name
        match = re.search(r"description:\s*(.+)", content)
        if match:
            desc = match.group(1).strip()
        results.append((d.name, desc))
    return results


_SKILL_DEPS = {"browser": ["playwright"]}
_SKILL_POST_INSTALL = {"browser": ["playwright", "install", "chromium"]}


def install_skill_deps(skill_name: str) -> None:
    """Install dependencies for a skill."""
    import subprocess
    import shutil

    deps = _SKILL_DEPS.get(skill_name)
    if not deps:
        return
    for dep in deps:
        try:
            __import__(dep)
        except ImportError:
            subprocess.run(
                [sys.executable, "-m", "pip", "install", dep],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=120,
            )
    post = _SKILL_POST_INSTALL.get(skill_name)
    if post:
        subprocess.run(
            [sys.executable, "-m"] + post,
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=300,
        )


def _install_system_deps() -> None:
    """Install whisper-cpp, ffmpeg and other system dependencies."""
    import shutil
    import subprocess
    from cli.ui import ui

    pkg_mgr = None
    for cmd, install_cmd in [
        ("apt-get", ["sudo", "apt-get", "install", "-y"]),
        ("dnf", ["sudo", "dnf", "install", "-y"]),
        ("pacman", ["sudo", "pacman", "-S", "--noconfirm"]),
        ("brew", ["brew", "install"]),
    ]:
        if shutil.which(cmd):
            pkg_mgr = (cmd, install_cmd)
            break

    if shutil.which("ffmpeg"):
        ui.ok("ffmpeg")
    elif pkg_mgr:
        with ui.spin("Installing ffmpeg..."):
            try:
                subprocess.run(pkg_mgr[1] + ["ffmpeg"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=120)
                ui.ok("ffmpeg installed")
            except (subprocess.TimeoutExpired, OSError):
                ui.fail("ffmpeg — install manually: sudo apt install ffmpeg")
    else:
        ui.warn("ffmpeg not found — install manually")

    if shutil.which("whisper-cpp") or shutil.which("whisper"):
        ui.ok("whisper-cpp")
        return

    whisper_dir = _ROOT / "vendor" / "whisper.cpp"
    whisper_bin = whisper_dir / "build" / "bin" / "whisper-cli"
    models_dir = _ROOT / "models"

    if whisper_bin.exists():
        ui.ok("whisper-cpp (already built)")
    else:
        if pkg_mgr and pkg_mgr[0] == "apt-get":
            with ui.spin("Installing build tools..."):
                subprocess.run(
                    ["sudo", "apt-get", "install", "-y", "build-essential", "cmake", "git"],
                    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=120,
                )

        vendor_dir = _ROOT / "vendor"
        vendor_dir.mkdir(exist_ok=True)

        if not whisper_dir.exists():
            with ui.spin("Cloning whisper.cpp..."):
                result = subprocess.run(
                    ["git", "clone", "--depth", "1", "https://github.com/ggerganov/whisper.cpp.git", str(whisper_dir)],
                    capture_output=True, timeout=120,
                )
            if result.returncode != 0:
                ui.fail("whisper-cpp: git clone failed")
                return

        build_dir = whisper_dir / "build"
        build_dir.mkdir(exist_ok=True)

        with ui.spin("Building whisper-cpp (1-2 min)..."):
            result = subprocess.run(["cmake", ".."], cwd=str(build_dir), capture_output=True, timeout=60)
            if result.returncode != 0:
                ui.fail("cmake failed — install: sudo apt install cmake")
                return
            result = subprocess.run(
                ["cmake", "--build", ".", "--config", "Release", "-j"],
                cwd=str(build_dir), capture_output=True, timeout=300,
            )
            if result.returncode != 0:
                ui.fail("Build failed — check build-essential")
                return

        ui.ok("whisper-cpp built")

    actual_bin = None
    for candidate in [whisper_dir / "build" / "bin" / "whisper-cli", whisper_dir / "build" / "bin" / "main"]:
        if candidate.exists():
            actual_bin = candidate
            break

    if actual_bin:
        env_file = _ROOT / ".env"
        if env_file.exists():
            content = env_file.read_text()
            if "WHISPER_CPP_PATH" not in content:
                content += f"\nWHISPER_CPP_PATH={actual_bin}\n"
                env_file.write_text(content)

    models_dir.mkdir(exist_ok=True)
    model_file = models_dir / "ggml-base.bin"

    if model_file.exists():
        ui.ok("whisper model")
    else:
        model_url = "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-base.bin"
        with ui.spin("Downloading whisper model (142MB)..."):
            try:
                result = subprocess.run(
                    ["curl", "-L", "-o", str(model_file), model_url],
                    timeout=300, capture_output=True,
                )
                if result.returncode == 0 and model_file.stat().st_size > 1000000:
                    ui.ok("whisper model downloaded")
                else:
                    model_file.unlink(missing_ok=True)
                    ui.fail("Download failed")
                    ui.info(f"curl -L -o {model_file} {model_url}")
            except (subprocess.TimeoutExpired, OSError):
                ui.fail("Download failed (timeout)")
