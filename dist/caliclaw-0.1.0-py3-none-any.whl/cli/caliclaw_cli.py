#!/usr/bin/env python3
"""caliclaw CLI — run as `caliclaw <command>`.

Thin dispatcher. Command implementations live in cli/commands/.
"""
from __future__ import annotations

import argparse
import asyncio
import os
import sys
from pathlib import Path

_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(_ROOT))
os.chdir(_ROOT)


# ── Sync commands ──


def cmd_tui(args: argparse.Namespace) -> None:
    from cli.tui import run_tui
    run_tui()


def cmd_start_sync(args: argparse.Namespace) -> None:
    import subprocess
    import time
    from cli.ui import ui

    debug = getattr(args, "debug", False)

    # Auto-init if not set up yet
    env_file = _ROOT / ".env"
    if not env_file.exists():
        ui.info("First run detected — running setup first")
        from cli.commands.init import cmd_init
        asyncio.run(cmd_init(args))

    pid_file = _ROOT / "data" / "caliclaw.pid"
    if pid_file.exists():
        pid = int(pid_file.read_text().strip())
        try:
            os.kill(pid, 0)
            ui.warn(f"Already running (pid {pid})")
            ui.next_steps(["caliclaw restart"])
            return
        except ProcessLookupError:
            pid_file.unlink()

    ui.banner_small(ui.vibe("start"))

    cmd = [sys.executable, str(_ROOT / "__main__.py")]
    if debug:
        cmd.append("--debug")

    if debug:
        subprocess.run(cmd, cwd=str(_ROOT))
    else:
        log_path = _ROOT / "logs" / "caliclaw.log"
        log_path.parent.mkdir(parents=True, exist_ok=True)
        log_file = open(log_path, "a")
        proc = subprocess.Popen(
            cmd, cwd=str(_ROOT), stdout=log_file, stderr=log_file,
            start_new_session=True,
        )
        pid_file.parent.mkdir(parents=True, exist_ok=True)
        pid_file.write_text(str(proc.pid))

        with ui.spin("Starting up..."):
            time.sleep(3)

        try:
            os.kill(proc.pid, 0)
            ui.ok(f"Running (pid {proc.pid})")
            code_file = _ROOT / "data" / "pairing_code.txt"
            if code_file.exists():
                code = code_file.read_text().strip()
                ui.c.print(f"\n  [bold yellow]Pair with your bot:[/bold yellow]")
                ui.c.print(f"  [bold]/pair {code}[/bold]")
                ui.c.print()
            ui.next_steps([
                "caliclaw logs       View logs",
                "caliclaw status     System status",
                "caliclaw stop       Stop bot",
            ])
        except ProcessLookupError:
            ui.fail("Process died on startup")
            ui.next_steps(["caliclaw logs       Check what went wrong"])


def cmd_stop_sync(args: argparse.Namespace) -> None:
    import signal
    from cli.ui import ui

    pid_file = _ROOT / "data" / "caliclaw.pid"
    if not pid_file.exists():
        ui.info("Not running.")
        return
    pid = int(pid_file.read_text().strip())
    try:
        os.kill(pid, signal.SIGTERM)
        ui.ok(f"{ui.vibe('stop')} (pid {pid})")
        pid_file.unlink()
    except ProcessLookupError:
        ui.info("Was not running.")
        pid_file.unlink()


def cmd_restart_sync(args: argparse.Namespace) -> None:
    import time
    args_stop = argparse.Namespace()
    cmd_stop_sync(args_stop)
    time.sleep(1)
    args.daemon = True
    cmd_start_sync(args)


def cmd_skills(args: argparse.Namespace) -> None:
    import shutil
    from cli.commands.init import install_skill_deps

    arg = (getattr(args, "skill_arg", "") or "").strip()
    extra = (getattr(args, "skill_extra", "") or "").strip()

    from cli.commands.init import _get_available_skills
    available = _get_available_skills()
    skill_names = {n for n, _ in available}
    config_file = _ROOT / "data" / "enabled_skills.txt"
    enabled = set()
    if config_file.exists():
        enabled = {l.strip() for l in config_file.read_text().split("\n") if l.strip()}

    if not arg:
        print(f"{'Skill':<18} {'Status':<10} {'Description'}")
        print("-" * 60)
        for name, desc in available:
            status = "ON" if name in enabled else "off"
            icon = "*" if name in enabled else " "
            print(f"{icon} {name:<17} {status:<10} {desc}")

    elif arg in ("new", "create", "add"):
        name = extra or input("Skill name: ").strip()
        if not name:
            print("Name required.")
            return
        desc = input("Description: ").strip()
        instructions = input("Instructions: ").strip()
        skill_dir = _ROOT / "skills" / name
        skill_dir.mkdir(parents=True, exist_ok=True)
        (skill_dir / "SKILL.md").write_text(
            f"---\nname: {name}\ndescription: {desc}\n---\n\n{instructions}\n", encoding="utf-8",
        )
        enabled.add(name)
        config_file.write_text("\n".join(sorted(enabled)) + "\n")
        print(f"Created: {name}")

    elif arg == "rm":
        if not extra:
            print("Usage: caliclaw skills rm <name>")
            return
        skill_dir = _ROOT / "skills" / extra
        if not skill_dir.exists():
            print(f"Skill not found: {extra}")
            return
        shutil.rmtree(skill_dir)
        enabled.discard(extra)
        config_file.write_text("\n".join(sorted(enabled)) + "\n")
        print(f"Removed: {extra}")

    elif arg in skill_names and extra == "on":
        enabled.add(arg)
        config_file.write_text("\n".join(sorted(enabled)) + "\n")
        install_skill_deps(arg)
        print(f"Enabled: {arg}")

    elif arg in skill_names and extra == "off":
        enabled.discard(arg)
        config_file.write_text("\n".join(sorted(enabled)) + "\n")
        print(f"Disabled: {arg}")

    elif arg in skill_names:
        skill_md = _ROOT / "skills" / arg / "SKILL.md"
        if skill_md.exists():
            print(skill_md.read_text(encoding="utf-8")[:1000])
        print(f"\nStatus: {'ON' if arg in enabled else 'off'}")

    else:
        print(f"Skill not found: {arg}")
        print("Use 'caliclaw skills' to see available skills.")


def cmd_auth(args: argparse.Namespace) -> None:
    import shutil
    import subprocess

    service = args.service
    if service == "status":
        print("Auth status:")
        if shutil.which("gh"):
            result = subprocess.run(["gh", "auth", "status"], capture_output=True, text=True)
            if result.returncode == 0:
                info = result.stderr.strip().split("\n")
                for line in info:
                    if "Logged in" in line or "account" in line.lower():
                        print(f"  GitHub: {line.strip()}")
                        break
                else:
                    print("  GitHub: authenticated")
            else:
                print("  GitHub: not authenticated")
        else:
            print("  GitHub: gh CLI not installed")
    elif service == "github":
        if not shutil.which("gh"):
            print("Install GitHub CLI first: https://cli.github.com")
            return
        subprocess.run(["gh", "auth", "login"])


def cmd_doctor(args: argparse.Namespace) -> None:
    import shutil
    from cli.ui import ui

    ui.banner_small("doctor")
    ui.c.print()

    checks = [
        ("Python", sys.version.split()[0], True),
        (".env", "found" if (_ROOT / ".env").exists() else "missing", (_ROOT / ".env").exists()),
        ("Database", "found" if (_ROOT / "data" / "caliclaw.db").exists() else "missing", (_ROOT / "data" / "caliclaw.db").exists()),
        ("Claude Code", shutil.which("claude") or "not found", bool(shutil.which("claude"))),
        ("ffmpeg", shutil.which("ffmpeg") or "not found", bool(shutil.which("ffmpeg"))),
    ]

    whisper_found = shutil.which("whisper-cpp") or shutil.which("whisper")
    if not whisper_found:
        for candidate in [_ROOT / "vendor" / "whisper.cpp" / "build" / "bin" / "whisper-cli", _ROOT / "vendor" / "whisper.cpp" / "build" / "bin" / "main"]:
            if candidate.exists():
                whisper_found = str(candidate)
                break
    checks.append(("whisper-cpp", whisper_found or "not found", bool(whisper_found)))

    model_path = _ROOT / "models" / "ggml-base.bin"
    checks.append(("whisper model", "found" if model_path.exists() else "not found", model_path.exists()))

    agents_dir = _ROOT / "agents" / "global" / "main"
    checks.append(("Main agent", "found" if agents_dir.exists() else "missing", agents_dir.exists()))

    all_ok = True
    for name, value, ok in checks:
        if ok:
            ui.ok(f"{name}: {value}")
        else:
            ui.fail(f"{name}: {value}")
            all_ok = False

    for sf in ["SOUL.md", "IDENTITY.md", "USER.md", "TOOLS.md"]:
        exists = (agents_dir / sf).exists() if agents_dir.exists() else False
        (ui.ok if exists else ui.warn)(f"{sf}{'' if exists else ' missing'}")

    if all_ok:
        ui.done("All checks passed.")
    else:
        ui.c.print()
        ui.fail("Some checks failed")
        ui.next_steps(["caliclaw init    Fix missing components"])


# ── Async commands ──


async def cmd_status(args: argparse.Namespace) -> None:
    from core.db import Database
    from monitoring.tracking import UsageTracker
    from cli.ui import ui

    db = Database()
    await db.connect()
    tracker = UsageTracker(db)
    summary = await tracker.get_today_summary()
    agents = await db.list_agents()
    limit_status = await tracker.check_limits()

    ui.banner_small("status")
    ui.c.print()
    pct = summary["total_percent"]
    bar_color = "green" if pct < 70 else "yellow" if pct < 90 else "red"
    ui.c.print(f"  Usage:    [{bar_color}]{pct:.1f}%[/{bar_color}] ({limit_status})")
    ui.c.print(f"  Requests: {summary['total_requests']}")
    ui.c.print(f"  Agents:   {len(agents)} registered")

    if summary["by_model"]:
        ui.c.print()
        ui.table(["Model", "Requests", "Usage"], [(m, str(d["count"]), f"{d['percent']:.1f}%") for m, d in summary["by_model"].items()])

    if agents:
        ui.c.print()
        rows = []
        for a in agents:
            color = {"active": "green", "paused": "yellow", "killed": "red"}.get(a["status"], "dim")
            rows.append((a["name"], a["scope"], f"[{color}]{a['status']}[/{color}]"))
        ui.table(["Agent", "Scope", "Status"], rows)

    async with db.db.execute("SELECT name, schedule_value, status FROM tasks ORDER BY name") as cur:
        tasks = [dict(r) for r in await cur.fetchall()]
    if tasks:
        ui.c.print()
        ui.table(["Task", "Schedule", "Status"], [(t["name"], t["schedule_value"], t["status"]) for t in tasks])

    await db.close()
    ui.c.print()


async def cmd_agents(args: argparse.Namespace) -> None:
    from core.db import Database
    from cli.ui import ui

    db = Database()
    await db.connect()
    agents = await db.list_agents()
    if not agents:
        ui.info("No agents registered.")
    else:
        rows = []
        for a in agents:
            color = {"active": "green", "paused": "yellow", "killed": "red"}.get(a["status"], "dim")
            rows.append((a["name"], a["scope"], f"[{color}]{a['status']}[/{color}]", a.get("project") or "—"))
        ui.table(["Name", "Scope", "Status", "Project"], rows)
    await db.close()


async def cmd_tasks(args: argparse.Namespace) -> None:
    from core.db import Database
    from cli.ui import ui

    db = Database()
    await db.connect()
    async with db.db.execute("SELECT * FROM tasks ORDER BY status, name") as cur:
        tasks = [dict(r) for r in await cur.fetchall()]
    if not tasks:
        ui.info("No scheduled tasks.")
    else:
        rows = [(str(t["id"]), t["name"], f"{t['schedule_type']}:{t['schedule_value']}", t.get("model", "—"), t["status"]) for t in tasks]
        ui.table(["ID", "Name", "Schedule", "Model", "Status"], rows)
    await db.close()


async def cmd_reset(args: argparse.Namespace) -> None:
    from core.db import Database

    target = (args.target or "").strip()
    if not target:
        print("What to reset?")
        print("  1. session   — archive active sessions")
        print("  2. agents    — kill ephemeral agents")
        print("  3. tasks     — pause all tasks")
        print("  4. all       — full reset")
        print("  0. cancel")
        choice = input("> ").strip()
        target = {"1": "session", "2": "agents", "3": "tasks", "4": "all"}.get(choice, "")
        if not target:
            print("Cancelled.")
            return

    if target not in ("session", "agents", "tasks", "all"):
        print(f"Unknown target: {target}. Use: session, agents, tasks, all")
        return

    db = Database()
    await db.connect()
    if target == "session":
        await db.db.execute("UPDATE sessions SET status = 'archived' WHERE status = 'active'")
        await db.db.commit()
        print("Sessions archived.")
    elif target == "agents":
        await db.db.execute("UPDATE agents SET status = 'killed' WHERE scope = 'ephemeral' AND status = 'active'")
        await db.db.commit()
        print("Ephemeral agents killed.")
    elif target == "tasks":
        await db.db.execute("UPDATE tasks SET status = 'paused'")
        await db.db.commit()
        print("All tasks paused.")
    elif target == "all":
        confirm = input("Full reset? (yes/no): ").strip().lower()
        if confirm not in ("yes", "y"):
            print("Cancelled.")
            await db.close()
            return
        await db.db.execute("UPDATE sessions SET status = 'archived' WHERE status = 'active'")
        await db.db.execute("UPDATE agents SET status = 'killed' WHERE scope = 'ephemeral'")
        await db.db.execute("UPDATE tasks SET status = 'paused'")
        await db.db.commit()
        print("Full reset done.")
    await db.close()


async def cmd_confirm(args: argparse.Namespace) -> None:
    from core.db import Database
    from security.approval import ApprovalManager

    db = Database()
    await db.connect()
    code = (args.code or "").strip()

    if not code:
        async with db.db.execute("SELECT * FROM approvals WHERE status = 'pending' ORDER BY created_at DESC") as cur:
            rows = [dict(r) for r in await cur.fetchall()]
        if not rows:
            print("No pending approvals.")
        else:
            print(f"Pending approvals ({len(rows)}):\n")
            for r in rows:
                print(f"  Code: {r['code']}  Agent: {r['agent_name']}  Action: {r['action']}  Level: {r['level']}")
        await db.close()
        return

    approval = await db.get_pending_approval(code)
    if not approval:
        print(f"No pending approval with code: {code}")
        await db.close()
        return

    print(f"  Agent:  {approval['agent_name']}")
    print(f"  Action: {approval['action']}")
    print(f"  Level:  {approval['level']}")
    confirm = input("\nApprove? (yes/no): ").strip().lower()

    mgr = ApprovalManager(db)
    await mgr.resolve(code, confirm in ("yes", "y"), "terminal")
    print("Approved." if confirm in ("yes", "y") else "Denied.")
    await db.close()


async def cmd_memory(args: argparse.Namespace) -> None:
    from intelligence.memory import MemoryManager
    mm = MemoryManager()
    query = (args.query or "").strip()

    if not query:
        entries = mm.load_all()
        if not entries:
            print("Memory is empty.")
        else:
            print(f"{'Name':<30} {'Type':<12} {'File':<30}")
            print("-" * 72)
            for e in entries:
                print(f"{e.name:<30} {e.type:<12} {e.filename:<30}")
    elif query == "flush":
        confirm = input("Flush ALL memory? This cannot be undone. (yes/no): ").strip().lower()
        if confirm in ("yes", "y"):
            for e in mm.load_all():
                mm.delete(e.filename)
            print("Memory flushed.")
    else:
        results = mm.search(query)
        if not results:
            print(f"Nothing found for '{query}'.")
        else:
            for e in results:
                print(f"\n## {e.name} ({e.type})")
                print(e.content[:500])


async def cmd_vault(args: argparse.Namespace) -> None:
    from security.vault import Vault
    import getpass

    vault = Vault()
    arg = (getattr(args, "vault_arg", "") or "").strip()
    value = (getattr(args, "vault_value", "") or "").strip()

    if arg == "init":
        pwd = getpass.getpass("Master password: ")
        pwd2 = getpass.getpass("Confirm: ")
        if pwd != pwd2:
            print("Passwords don't match.")
            return
        vault.initialize(pwd)
        print("Vault initialized.")
    elif not arg:
        pwd = getpass.getpass("Master password: ")
        if not vault.unlock(pwd):
            print("Wrong password.")
            return
        keys = vault.list_keys()
        if not keys:
            print("Vault is empty.")
        else:
            print(f"Secrets ({len(keys)}):")
            for k in keys:
                print(f"  - {k}")
    elif value:
        pwd = getpass.getpass("Master password: ")
        if not vault.unlock(pwd):
            print("Wrong password.")
            return
        vault.set(arg, value)
        print(f"Stored: {arg}")
    else:
        pwd = getpass.getpass("Master password: ")
        if not vault.unlock(pwd):
            print("Wrong password.")
            return
        try:
            val = vault.get(arg)
            print(f"{arg} = {val}")
        except KeyError:
            print(f"Not found: {arg}")


async def cmd_logs(args: argparse.Namespace) -> None:
    log_file = _ROOT / "logs" / "caliclaw.log"
    if not log_file.exists():
        print("No logs yet.")
        return
    lines = log_file.read_text().strip().split("\n")
    n = getattr(args, "lines", 50) or 50
    for line in lines[-n:]:
        print(line)


# ── Main ──


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="caliclaw",
        description="caliclaw — Personal AI Assistant",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Commands:
  init              First-time setup
  start             Start bot (daemon)
  start --debug     Start in foreground
  stop              Stop bot
  restart           Restart bot
  chat              Terminal chat
  status            System status
  agents            List agents
  tasks             List scheduled tasks
  memory            Show all memory
  memory <query>    Search memory
  memory flush      Wipe all memory
  skills            List skills
  skills <name>     Show skill details
  skills <name> on  Enable skill
  skills <name> off Disable skill
  skills new        Create skill
  skills rm <name>  Remove skill
  confirm           List pending approvals
  confirm <code>    Approve action
  reset             Interactive reset
  vault             List secrets
  vault <key>       Get secret
  vault <key> <val> Set secret
  logs              Show recent logs (default 50)
  logs <N>          Show last N lines
  doctor            Health check
  migrate <path>    Migrate from another *claw project
""",
    )
    sub = parser.add_subparsers(dest="command")

    sub.add_parser("init", help="First-time setup")
    p_start = sub.add_parser("start", help="Start bot")
    p_start.add_argument("--debug", action="store_true")
    sub.add_parser("stop", help="Stop bot")
    p_restart = sub.add_parser("restart", help="Restart bot")
    p_restart.add_argument("--debug", action="store_true")
    sub.add_parser("chat", help="Terminal chat")
    sub.add_parser("tui", help="Terminal chat (alias)")
    sub.add_parser("status", help="System status")
    sub.add_parser("agents", help="List agents")
    sub.add_parser("tasks", help="Scheduled tasks")

    p_skills = sub.add_parser("skills", help="List or manage skills")
    p_skills.add_argument("skill_arg", nargs="?", default="")
    p_skills.add_argument("skill_extra", nargs="?", default="")

    p_auth = sub.add_parser("auth", help="Authenticate services")
    p_auth.add_argument("service", choices=["github", "status"])
    sub.add_parser("doctor", help="Health check")

    p_confirm = sub.add_parser("confirm", help="Approve or list pending actions")
    p_confirm.add_argument("code", nargs="?", default="")
    p_approve = sub.add_parser("approve")
    p_approve.add_argument("code", nargs="?", default="")

    p_reset = sub.add_parser("reset", help="Reset system state")
    p_reset.add_argument("target", nargs="?", default="")

    p_memory = sub.add_parser("memory", help="Show or search memory")
    p_memory.add_argument("query", nargs="?", default="")

    p_vault = sub.add_parser("vault", help="Manage secrets")
    p_vault.add_argument("vault_arg", nargs="?", default="")
    p_vault.add_argument("vault_value", nargs="?", default="")

    p_logs = sub.add_parser("logs", help="Show recent logs")
    p_logs.add_argument("lines", nargs="?", type=int, default=50)

    from cli.migrate import register_migrate_parser
    register_migrate_parser(sub)

    args = parser.parse_args()
    if not args.command:
        parser.print_help()
        return

    # Sync commands
    sync_map = {
        "chat": cmd_tui, "tui": cmd_tui,
        "start": cmd_start_sync, "stop": cmd_stop_sync, "restart": cmd_restart_sync,
        "skills": cmd_skills, "auth": cmd_auth, "doctor": cmd_doctor,
    }
    if args.command in sync_map:
        sync_map[args.command](args)
        return

    if args.command == "migrate":
        from cli.migrate import cmd_migrate
        cmd_migrate(args)
        return

    # Async commands
    async_map = {
        "init": None,  # special
        "status": cmd_status, "agents": cmd_agents, "tasks": cmd_tasks,
        "confirm": cmd_confirm, "approve": cmd_confirm,
        "reset": cmd_reset, "memory": cmd_memory,
        "vault": cmd_vault, "logs": cmd_logs,
    }

    if args.command == "init":
        from cli.commands.init import cmd_init
        asyncio.run(cmd_init(args))
    elif args.command in async_map:
        asyncio.run(async_map[args.command](args))


if __name__ == "__main__":
    main()
