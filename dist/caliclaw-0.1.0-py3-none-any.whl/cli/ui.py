"""CLI UI module — Rich output, ASCII art, loading messages.

Usage:
    from cli.ui import ui
    ui.banner()
    ui.ok("Connected")
    ui.fail("Token invalid")
    with ui.spin("Flexing the claws..."):
        install_deps()
    ui.table(["Name", "Status"], rows)
"""
from __future__ import annotations

import random
import time
from contextlib import contextmanager
from typing import List, Optional, Tuple

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text
from rich import box

console = Console()

# ── ASCII Art ──

LOGO = r"""
       ___                                  ___
      |   |                                |   |
     _|___|_  ===========================  _|___|_
    /  ___  \=    C A L I C L A W        =/  ___  \
   |  |   |  |===========================|  |   |  |
    \ '___' /                              \ '___' /
     |_____|                                |_____|
"""

LOGO_SMALL = r"""  ═══{ CALICLAW }═══"""

LOGO_BANNER = r"""
     ___                                                             ___
    |   | ██████╗  █████╗ ██╗     ██╗ ██████╗██╗      █████╗ ██╗  ██╗   |
   _|___|_██╔════╝██╔══██╗██║     ██║██╔════╝██║     ██╔══██╗██║  ██║___|_
  / ___  \██║     ███████║██║     ██║██║     ██║     ███████║██║ █╗██/ ___  \
 |  | |  |██║     ██╔══██║██║     ██║██║     ██║     ██╔══██║██║███╗|  | |  |
  \_'_'_/ ╚██████╗██║  ██║███████╗██║╚██████╗███████╗██║  ██║╚███╔██\_'_'_/
   |___|   ╚═════╝╚═╝  ╚═╝╚══════╝╚═╝ ╚═════╝╚══════╝╚═╝  ╚═╝ ╚══╝ |___|
"""

# ── Gym-themed loading messages ──

MESSAGES_INIT = [
    "Flexing the claws...",
    "Loading the bar...",
    "Chalking up...",
    "Stretching before the lift...",
    "Setting up the rack...",
]

MESSAGES_START = [
    "Warming up...",
    "Entering the gym...",
    "Cracking knuckles...",
    "Pre-workout kicking in...",
    "Lacing up...",
]

MESSAGES_PROCESSING = [
    "Crunching reps...",
    "Lifting heavy thoughts...",
    "No pain no gain...",
    "Grinding it out...",
    "In the zone...",
    "One more rep...",
    "Beast mode...",
]

MESSAGES_DONE = [
    "Racked.",
    "Clean lift.",
    "PR achieved.",
    "Set complete.",
    "No spotter needed.",
]

MESSAGES_STOP = [
    "Racked the weights.",
    "Cooldown initiated.",
    "Rest day earned.",
    "Dropped the bar.",
]

MESSAGES_ERROR = [
    "Failed the rep.",
    "Bad form detected.",
    "Need a spotter.",
    "Missed the lift.",
]

MESSAGES_FLUSH = [
    "Brain day off.",
    "Mind-muscle disconnect.",
    "Reset the gains.",
]

MESSAGES_SQUEEZE = [
    "Squeezing it out...",
    "Compressing the pump...",
    "Cutting weight...",
]


def _pick(messages: list[str]) -> str:
    return random.choice(messages)


# ── UI Class ──


class UI:
    """Rich-based CLI output helpers."""

    def __init__(self):
        self.c = console

    # ── Banner ──

    def banner(self, subtitle: str = "") -> None:
        """Show the full branded banner."""
        text = Text()
        text.append(LOGO_BANNER, style="bold cyan")
        if subtitle:
            text.append(f"\n  {subtitle}", style="dim")
        self.c.print(text)

    def banner_small(self, subtitle: str = "") -> None:
        """Compact banner for smaller contexts."""
        self.c.print(f"[bold cyan]🔱 caliclaw[/bold cyan]  [dim]{subtitle}[/dim]")

    def logo(self) -> None:
        """Show ASCII art logo."""
        self.c.print(LOGO, style="cyan")

    # ── Status messages ──

    def ok(self, msg: str) -> None:
        self.c.print(f"  [green]✓[/green] {msg}")

    def fail(self, msg: str) -> None:
        self.c.print(f"  [red]✗[/red] {msg}")

    def warn(self, msg: str) -> None:
        self.c.print(f"  [yellow]![/yellow] {msg}")

    def info(self, msg: str) -> None:
        self.c.print(f"  [dim]→[/dim] {msg}")

    def step(self, n: int, total: int, msg: str) -> None:
        self.c.print(f"\n  [bold cyan][{n}/{total}][/bold cyan] {msg}")

    def done(self, msg: str = "") -> None:
        text = msg or _pick(MESSAGES_DONE)
        self.c.print(f"\n  [bold green]✓ {text}[/bold green]")

    def vibe(self, category: str = "processing") -> str:
        """Get a themed message for the given category."""
        msgs = {
            "init": MESSAGES_INIT,
            "start": MESSAGES_START,
            "processing": MESSAGES_PROCESSING,
            "done": MESSAGES_DONE,
            "stop": MESSAGES_STOP,
            "error": MESSAGES_ERROR,
            "flush": MESSAGES_FLUSH,
            "squeeze": MESSAGES_SQUEEZE,
        }
        return _pick(msgs.get(category, MESSAGES_PROCESSING))

    # ── Spinner ──

    @contextmanager
    def spin(self, msg: str = "", category: str = "processing"):
        """Context manager that shows a spinner during long operations."""
        text = msg or _pick(MESSAGES_PROCESSING)
        status = self.c.status(f"[cyan]{text}[/cyan]", spinner="dots")
        status.start()
        try:
            yield status
        finally:
            status.stop()

    # ── Tables ──

    def table(
        self,
        columns: List[str],
        rows: List[Tuple],
        title: str = "",
        style: str = "cyan",
    ) -> None:
        t = Table(
            title=title or None,
            box=box.SIMPLE,
            header_style=f"bold {style}",
            show_edge=False,
            pad_edge=False,
            padding=(0, 2),
        )
        for col in columns:
            t.add_column(col)
        for row in rows:
            t.add_row(*[str(c) for c in row])
        self.c.print(t)

    # ── Panels ──

    def panel(self, content: str, title: str = "", style: str = "cyan") -> None:
        self.c.print(Panel(content, title=title or None, border_style=style, padding=(0, 1)))

    # ── Next steps ──

    def next_steps(self, steps: List[str]) -> None:
        """Show actionable next steps after a command."""
        self.c.print()
        self.c.print("  [bold]Next:[/bold]")
        for s in steps:
            self.c.print(f"    [dim]$[/dim] {s}")
        self.c.print()

    # ── Separator ──

    def sep(self) -> None:
        self.c.print("[dim]─[/dim]" * 50)


# Singleton
ui = UI()
